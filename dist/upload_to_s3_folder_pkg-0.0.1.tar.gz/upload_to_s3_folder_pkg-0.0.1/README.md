## Description
* Package allows you to rname a file with spaces
* Package allows you determine which folders in S3 to upload to
